% Cluster Model Simulation (CCToolbox/simulation)
%  CCToolbox 1.0
%
% Subfolders
%  simulation\examples\  - Example model scripts
%
% Simulation functions
%  simulate_trajs        - Simulate from specified cluster model
%
% See also CCTOOLBOX

% Scott J. Gaffney   18 May 2005
% University of California, Irvine
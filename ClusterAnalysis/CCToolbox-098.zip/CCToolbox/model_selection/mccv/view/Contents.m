% MCCV Visualization (CCToolbox/model_selection/mccv/view)
%  CCToolbox 1.0
%
% Visualization
%  ShowMCCV        - View MCCV clustering results
%
% See also CCTOOLBOX

% Scott J. Gaffney   18 May 2005
% University of California, Irvine
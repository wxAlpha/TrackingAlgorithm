% Model Selection Visualization (CCToolbox/model_selection/view)
%  CCToolbox 1.0
%
% Visualization
%  Show_Test       - Plot test results
%  Show_Test_Diff  - Plot test results
%  Make_Small      - Pull out the test statistics from an MCCV or CV struct
%
% See also CCTOOLBOX

% Scott J. Gaffney   18 May 2005
% University of California, Irvine